
-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE IF NOT EXISTS `bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `seats` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `movie_id` (`movie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `movie_id`, `seats`, `total_price`, `booking_date`) VALUES
(1, 0, 0, 1, 200.00, '2024-10-23 02:35:57'),
(2, 0, 0, 1, 200.00, '2024-10-23 02:36:01'),
(3, 0, 0, 1, 200.00, '2024-10-23 02:36:27'),
(4, 0, 0, 1, 200.00, '2024-10-23 02:36:45'),
(5, 0, 0, 1, 200.00, '2024-10-23 02:36:56'),
(6, 0, 0, 1, 200.00, '2024-10-23 02:37:04'),
(7, 0, 0, 1, 200.00, '2024-10-24 15:12:45'),
(8, 0, 0, 2, 400.00, '2024-10-24 15:12:53');
