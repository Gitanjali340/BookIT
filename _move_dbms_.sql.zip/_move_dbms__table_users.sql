
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(2, 'Gitanjali', 'gpandey22extc@student.mes.ac.in', '$2y$10$MQA6zLgegYTe78HRCEJwL.olXm0onQQPP1pHz7J86Y9/dABbeL4gO', '2024-10-20 07:52:30'),
(7, 'Gitanjali2', 'gitanjali5704pandey@gmail.com', '$2y$10$EUL8iuWk5XkFOPB.o4Y8fuXBF7a26Pr0l1ffbS1su/u5n7Ixb6kbK', '2024-10-25 14:21:09');
